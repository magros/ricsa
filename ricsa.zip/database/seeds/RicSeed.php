<?php

use Illuminate\Database\Seeder;
use App\Ric;

class RicSeed extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $proyects = [];
    }
}
