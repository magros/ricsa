@extends('layouts.admin.layout')

@section('meta_title')
    Dashboard
@endsection

@section('content')
   <h1>Hola</h1>

@endsection

@push('scripts')

@endpush
