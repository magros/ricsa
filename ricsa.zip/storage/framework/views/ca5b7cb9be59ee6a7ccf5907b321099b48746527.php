<?php $__env->startSection('meta_title'); ?>
    Materiales
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_title'); ?>
    Materiales
<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta_extra'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_action'); ?>
    <a href="<?php echo e(route('ingenieria.material.create')); ?>" class="btn btn-primary">+ Agregar Material</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Materiales en sistema</h5>
                    <div class="ibox-tools">
                        <a class="collapse-link">
                            <i class="fa fa-chevron-up"></i>
                        </a>
                    </div>
                </div>
                <div class="ibox-content">

                    <table class="table table-striped table-hover table-dark dataTables-users" >
                        <thead class="thead-dark">
                        <tr>
                            <th>Descipcion</th>
                            <th>Especificación</th>
                            <th>Precio</th>
                            <th>Recurso / Consumible</th>
                            <th>Acciones</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $materials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $material): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="gradeA" id="item-<?php echo e($material->id); ?>">
                                <td>
                                    <?php echo e($material->description); ?>

                                </td>
                                <td>
                                    <?php echo e($material->specification); ?>

                                </td>
                                <td>
                                    <?php echo e($material->price); ?>

                                </td>
                                <td>
                                    <?php echo e($material->r_rc); ?>

                                </td>
                                <td>
                                    <a href="<?php echo e(route('ingenieria.material.edit',[$material->id])); ?>" class="btn btn-outline-light">
                                        <i class="fa fa-pencil-square-o"></i>
                                    </a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>

    <div class="modal inmodal fade" id="delete-modal" tabindex="-1" role="dialog"  aria-hidden="true">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                    <h4 class="modal-title">¡Atención!</h4>
                </div>
                <div class="modal-body">
                    <p>
                        <strong>
                            ¿Estás seguro de borrar el cliente?
                        </strong>
                        <br><br>
                        Se borrarán también cualquier información y registros de esta cuenta.
                        <br><br>
                        Esta acción es irreversible.
                        <br><br>
                        ¿Deseas continuar?
                        </strong>
                    </p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-white" data-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-danger" id="delete-action-btn" data-tango="0">Borrar</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <?php echo HTML::script('static/admin/js/plugins/dataTables/jquery.dataTables.js'); ?>

    <?php echo HTML::script('static/admin/js/plugins/dataTables/dataTables.bootstrap.js'); ?>

    <?php echo HTML::script('static/admin/js/plugins/dataTables/dataTables.responsive.js'); ?>

    <?php echo HTML::script('static/admin/js/plugins/dataTables/dataTables.tableTools.min.js'); ?>

<script type="text/javascript">
    $(function(){
        $('.dataTables-users').dataTable({
            responsive: true,
        });

        $(".delete").click(function(event) {
            event.preventDefault();
            var id = $(this).data('id');
            $("#delete-action-btn").attr('data-tango',id);
            $("#delete-modal").modal();
        });

        $("#delete-action-btn").click(function(event) {
            event.preventDefault();
            var id = $(this).attr('data-tango');
            $.ajax({
                url: '<?php echo e(url('cotizacion/cliente/delet')); ?>/'+id,
                type: 'DELETE',
                dataType: 'json',
            })
                .done(function(data) {
                    $("#item-"+id).remove();
                    $("#delete-modal").modal('hide');
                    toastr.success('Se ha eliminado la información correctamente');
                })
                .fail(function() {
                    console.log(data);
                });


        });

    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\Users\mario\Documents\dev\ricsa\resources\views/ingenieria/materials/index.blade.php */ ?>