<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Administración | Login</title>

    <?php echo HTML::style('static/bower_components/bootstrap/dist/css/bootstrap.min.css'); ?>


    <?php echo HTML::style('static/bower_components/font-awesome/css/font-awesome.min.css'); ?>


    <?php echo HTML::style('static/admin/css/animate.css'); ?>

    <?php echo HTML::style('static/admin/css/style.css'); ?>


</head>

<body class="gray-bg">

    <div class="middle-box text-center loginscreen  animated fadeInDown">
        <div>
            <div>

                <h1 class="logo-name">
                    <img src="<?php echo e(asset('static/images/logo.png')); ?>" alt="<?php echo e(config('app.name')); ?>">
                </h1>

            </div>
            <h3>Panel administrativo</h3>
            <p>
                Iniciar sesión
            </p>
            <?php echo Form::open(['url'=>'login', 'method'=>'post', 'id'=>'admin-login-form', 'class'=>'m-t', 'role'=>'form']); ?>

                <?php echo e(csrf_field()); ?>


                <div class="form-group<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">

                    <?php echo Form::email('email',old('email'),
                    [
                        'class'=>'form-control',
                        'required'=>'true',
                        'data-required-error'=>'El campo no puede estar vacío.',
                        'data-error'=>'El correo electrónico no tiene el formato correcto.',
                        'autocomplete'=>'off',
                        'id'=>'email',
                        'placeholder' => 'E-mail'
                    ]); ?>

                </div>
                <div class="form-group">
                    <?php echo Form::password('password',
                    [
                        'class'=>'form-control',
                        'required'=>'true',
                        'data-required-error'=>'El campo no puede estar vacío.',
                        'autocomplete'=>'off',
                        'id'=>'password',
                        'placeholder' => 'Contraseña'
                    ]); ?>

                </div>
                <button type="submit" class="btn btn-primary block full-width m-b">Iniciar sesión</button>

                <a href="#"><small>¿Olvidaste la contraseña?</small></a>
            <?php echo Form::close(); ?>

            <p class="m-t"> <small>&copy; <?php echo e(date('Y')); ?></small> </p>
        </div>
    </div>

    <!-- Mainly scripts -->

    <?php echo HTML::script('static/bower_components/jquery/dist/jquery.min.js'); ?>

    <?php echo HTML::script('static/bower_components/bootstrap/dist/js/bootstrap.min.js'); ?>


</body>

</html>

<?php /* C:\Users\mario\Documents\dev\ricsa\resources\views/admin/login.blade.php */ ?>