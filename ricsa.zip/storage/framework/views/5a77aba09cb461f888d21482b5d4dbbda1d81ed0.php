<?php $__env->startSection('meta_title'); ?>
    Clientes
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_title'); ?>
    Clientes
<?php $__env->stopSection(); ?>

<?php $__env->startSection('meta_extra'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_action'); ?>
    <a href="<?php echo e(route('cotizacion.client.alta')); ?>" class="btn btn-primary">+ Crear cliente</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">
    <form action="route<?php echo e(route('cotizacion.rics')); ?>" method="get">
        <div class="col-lg-4">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Buscar por clientes</h5>
                    <div class="ibox-tools">
                        <a class="collapse-link">
                            <i class="fa fa-chevron-up"></i>
                        </a>
                    </div>
                </div>
                <div class="ibox-content">

                    <div class="row">
                        <div class="col-md-12">
                            <input id="check-0" type="checkbox" value="all" name="c[]" class="all" <?php echo e((is_array($clients)&&in_array('all',$clients)) ? 'checked="checked"' : ''); ?>>
                            <label for="check-0">Clientes</label>

                            <?php $__currentLoopData = $clients_in_system; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $client): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <input id="check-<?php echo e($client->id); ?>" name="c[]" value="<?php echo e($client->id); ?>" type="checkbox" <?php echo e((is_array($clients)&&in_array($client->id,$clients)) ? 'checked="checked"' : ''); ?>>
                            <label for="check-<?php echo e($client->id); ?>"><?php echo e($client->company); ?></label>
                            <br>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="col-md-12">
                            <button class="panel-cancel">Cancelar</button>
                            <button class="panel-apply" type="submit">Buscar</button>
                        </div>
                    </div>

                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Buscar por estatus</h5>
                    <div class="ibox-tools">
                        <a class="collapse-link">
                            <i class="fa fa-chevron-up"></i>
                        </a>
                    </div>
                </div>
                <div class="ibox-content">
                    <form>
                        <label class="label-radio">Propuesta
                            <input type="radio" name='e' value="1" checked="checked"/>
                            <span class="checkmark"></span>
                        </label>
                        <br>
                        <label class="label-radio">Pendiente
                            <input type="radio" name='e' value="2" checked="checked"/>
                            <span class="checkmark"></span>
                        </label>
                        <br>
                        <label class="label-radio">Aprobado
                            <input type="radio" name='e' value="3" checked="checked"/>
                            <span class="checkmark"></span>
                        </label>
                        <br>
                        <label class="label-radio">Coizando
                            <input type="radio" name='e' value="4" checked="checked"/>
                            <span class="checkmark"></span>
                        </label>
                        <br>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-lg-4">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Buscar por complejidad</h5>
                    <div class="ibox-tools">
                        <a class="collapse-link">
                            <i class="fa fa-chevron-up"></i>
                        </a>
                    </div>
                </div>
                <div class="ibox-content">
                    <form>
                        <label class="label-radio">Baja Complejidad
                            <input type="radio" name='o' value="1" checked="checked"/>
                            <span class="checkmark"></span>
                        </label>
                        <br>
                        <label class="label-radio">Mediana Complejidad
                            <input type="radio" name='o' value="2" checked="checked"/>
                            <span class="checkmark"></span>
                        </label>
                        <br>
                        <label class="label-radio">Alta Complejidad
                            <input type="radio" name='o' value="3" checked="checked"/>
                            <span class="checkmark"></span>
                        </label>
                        <br>
                    </form>
                </div>
            </div>
        </div>
    </form>

</div>

<div class="row">
    <div class="col-lg-12">
        <div class="ibox float-e-margins">
            <div class="ibox-title">
                <h5>Cotizaciones en sistema</h5>
                <div class="ibox-tools">
                    <a class="collapse-link">
                        <i class="fa fa-chevron-up"></i>
                    </a>
                </div>
            </div>
            <div class="ibox-content">

                <table class="table table-striped table-bordered table-hover dataTables-users" >
                    <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Cliente</th>
                        <th>Complejidad</th>
                        <th>Estatus</th>
                        <th>Acciones</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $rics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ric): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="gradeA" id="item-<?php echo e($ric->id); ?>">
                            <td>
                                <?php echo e($ric->name_proyect); ?>

                            </td>
                            <td>
                                <?php echo e($ric->customer->company); ?>

                            </td>
                            <td>
                                <?php if($ric->complexity == 1): ?>
                                    Baja Complejidad
                                <?php endif; ?>
                                <?php if($ric->complexity == 2): ?>
                                    Mediana Complejidad
                                <?php endif; ?>
                                <?php if($ric->complexity == 3): ?>
                                    Alta Complejidad
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($ric->status == 1): ?>
                                    Propuesta
                                <?php endif; ?>
                                <?php if($ric->status == 2): ?>
                                    Aprubado
                                <?php endif; ?>
                                <?php if($ric->status == 3): ?>
                                    Ric
                                <?php endif; ?>
                            </td>
                            <td>
                                <a href="<?php echo e(route('cotizacion.client.edit',[$ric->id])); ?>" class="btn btn-white">
                                    <i class="fa fa-pencil-square-o"></i>
                                </a>
                                <a href="#" class="btn btn-white delete" data-id="<?php echo e($ric->id); ?>">
                                    <i class="fa fa-trash"></i>
                                </a>
                                <?php if($ric->complexity > 1): ?>
                                    <a href="#" class="btn btn-white delete" data-id="<?php echo e($ric->id); ?>">
                                        <i class="fa fa-check"></i>
                                    </a>
                                <?php endif; ?>
                                <?php if($ric->complexity == 1 || $ric->status == 2): ?>
                                    <a href="<?php echo e(route('cotizacion.quoting')); ?>" class="btn btn-white" data-id="<?php echo e($ric->id); ?>">
                                        <i class="glyphicon glyphicon-plus"></i>
                                    </a>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <?php echo HTML::script('static/admin/js/plugins/dataTables/jquery.dataTables.js'); ?>

    <?php echo HTML::script('static/admin/js/plugins/dataTables/dataTables.bootstrap.js'); ?>

    <?php echo HTML::script('static/admin/js/plugins/dataTables/dataTables.responsive.js'); ?>

    <?php echo HTML::script('static/admin/js/plugins/dataTables/dataTables.tableTools.min.js'); ?>

<script type="text/javascript">
    $(function(){

    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\Users\mario\Documents\dev\ricsa\resources\views/reportes/portafoliorics.blade.php */ ?>