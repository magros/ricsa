<?php $__env->startSection('meta_title'); ?>
    <?php if(!isset($dollar)): ?>
        Crear valor de la moneda
    <?php else: ?>
        Editando <?php echo e($dollar->name); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_title'); ?>
    <?php if(!isset($dollar)): ?>
        Crear valor de la moneda
    <?php else: ?>
        Editando <?php echo e($dollar->name); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_action'); ?>
<a href="<?php echo e(route('precio.dollar')); ?>" class="btn btn-white">&lt; Regresar a monedas</a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-8">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Información</h5>
                    <div class="ibox-tools">
                        <a class="collapse-link">
                            <i class="fa fa-chevron-up"></i>
                        </a>
                    </div>
                </div>
                <div class="ibox-content">
                    <div class="row">
                        <div class="col-sm-12">
                            <?php if(!isset($dollar)): ?>
                                <?php echo Form::open(['route'=>'precio.dollar.save','id'=>'user-form', 'files'=>true,'data-toggle' => 'validator',]); ?>

                            <?php else: ?>
                                <?php echo Form::model($dollar, [
                                    'method' => 'patch',
                                    'route' => ['precio.dollar.update', $dollar->id],
                                    'id'=>'category-form',
                                    'files' => true,
                                    'data-toggle' => 'validator',
                                ]); ?>

                            <?php endif; ?>
                                <div class="form-group">
                                    <label for="name">Nombre</label>
                                    <?php echo Form::text('name',old('name'),[
                            			'class'=>'form-control','placeholder'=>'Nombre',
                            			 'autocomplete'=>'off', 'id' => 'name',
                                         'data-required-error' => 'Este campo es obligatorio',
                            			 'required' => '', 'maxlength' => '100','disabled'
                                    ]); ?>

                                    <input id="name" name="name" value="<?php echo e($dollar->name); ?>" class="hidden">
                                    <div class="help-block with-errors"></div>
                                </div>

                                <div class="form-group">
                                    <label for="price">Precio</label>
                                    <?php echo Form::text('price',old('price'),[
                            			'class'=>'form-control','placeholder'=>'Precio',
                            			'required'=>'', 'autocomplete'=>'off', 'id' => 'price',
                            			'data-required-error' => 'Este campo es obligatorio','maxlength' => '100'
                            		]); ?>

                                    <div class="help-block with-errors"></div>
                                </div>

                                <div>
                                    <button class="btn btn-lg btn-primary pull-right m-t-n-xs" type="submit"><strong>Guardar</strong></button>
                                </div>
                            <?php echo Form::close(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dyn_js'); ?>


<script type="text/javascript">
    $(function(){

    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\Users\mario\Documents\dev\ricsa\resources\views/precio/dollars/createoredit.blade.php */ ?>