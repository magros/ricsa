<?php $__env->startSection('meta_title'); ?>
    <?php if(!isset($client)): ?>
        Crear usuario
    <?php else: ?>
        Editando <?php echo e($client->name); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_title'); ?>
    <?php if(!isset($client)): ?>
        Crear usuario
    <?php else: ?>
        Editando <?php echo e($client->getFullName); ?>

    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_action'); ?>
<a href="<?php echo e(route('cotizacion.client')); ?>" class="btn btn-white">&lt; Regresar a clientes</a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Información</h5>
                    <div class="ibox-tools">
                        <a class="collapse-link">
                            <i class="fa fa-chevron-up"></i>
                        </a>
                    </div>
                </div>
                <div class="ibox-content">
                    <div class="row">
                        <div class="col-sm-12">
                            <?php if(!isset($client)): ?>
                                <?php echo Form::open(['route'=>'cotizacion.client.save','id'=>'user-form', 'files'=>true,'data-toggle' => 'validator',]); ?>

                            <?php else: ?>
                                <?php echo Form::model($client, [
                                    'method' => 'patch',
                                    'route' => ['cotizacion.client.update', $client->id],
                                    'id'=>'category-form',
                                    'files' => true,
                                    'data-toggle' => 'validator',
                                ]); ?>

                            <?php endif; ?>
                                <div class="form-group">
                                    <label for="name">Nombre</label>
                                    <?php echo Form::text('name',old('name'),[
                            			'class'=>'form-control','placeholder'=>'Nombre',
                            			 'autocomplete'=>'off', 'id' => 'name',
                            			 'data-required-error' => 'Este campo es obligatorio',
                            			 'required' => '', 'maxlength' => '100'
                            		]); ?>

                                    <div class="help-block with-errors"></div>
                                </div>

                                <div class="form-group">
                                    <label for="company">Empresa</label>
                                    <?php echo Form::text('company',old('company'),[
                            			'class'=>'form-control','placeholder'=>'Empresa',
                            			'required'=>'', 'autocomplete'=>'off', 'id' => 'company',
                            			'data-required-error' => 'Este campo es obligatorio','maxlength' => '100'
                            		]); ?>

                                    <div class="help-block with-errors"></div>
                                </div>

                                <div class="form-group">
                                    <label for="email">E-mail</label>
                                    <?php echo Form::email('email',old('email'),[
                            			'class'=>'form-control','placeholder'=>'E-mail de la ceunta',
                            			'required'=>'', 'autocomplete'=>'off', 'id' => 'email',
                            			'data-required-error' => 'Este campo es obligatorio',
                            			'data-error' => 'Introduce una dirección de correo válida',
                                        'maxlength' => '100'
                            		]); ?>

                                    <div class="help-block with-errors"></div>
                                </div>

                                <div class="form-group">
                                    <label for="phone">Teléfono</label>
                                    <?php echo Form::text('phone',old('phone'),[
                            			'class'=>'form-control','placeholder'=>'Teléfono',
                            			'required'=>'', 'autocomplete'=>'off', 'id' => 'phone',
                            			'data-required-error' => 'Este campo es obligatorio', 'maxlength' => '15'
                            		]); ?>

                                    <div class="help-block with-errors"></div>
                                </div>

                                <div>
                                    <button class="btn btn-lg btn-primary pull-right m-t-n-xs" type="submit"><strong>Guardar</strong></button>
                                </div>
                            <?php echo Form::close(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dyn_js'); ?>


<script type="text/javascript">
    $(function(){

    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\Users\mario\Documents\dev\ricsa\resources\views/cotizacion/clients/createoredit.blade.php */ ?>