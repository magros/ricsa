<?php $__env->startSection('meta_title'); ?>
    <?php if(!isset($materials)): ?>
        Agregar material
    <?php else: ?>
        Editando
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page_title'); ?>
    <?php if(!isset($materials)): ?>
        Agregar material
    <?php else: ?>
        Editando
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_action'); ?>
<a href="<?php echo e(route('ingenieria.material')); ?>" class="btn btn-white">&lt; Regresar a materiales</a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Información</h5>
                    <div class="ibox-tools">
                        <a class="collapse-link">
                            <i class="fa fa-chevron-up"></i>
                        </a>
                    </div>
                </div>
                <div class="ibox-content">
                    <div class="row">
                        <div class="col-sm-12">
                            <?php if(!isset($materials)): ?>
                                <?php echo Form::open(['route'=>'ingenieria.material.store','id'=>'material-form', 'files'=>true,'data-toggle' => 'validator',]); ?>

                            <?php else: ?>
                                <?php echo Form::model($materials, [
                                    'method' => 'patch',
                                    'route' => ['ingenieria.material.update', $materials->id],
                                    'id'=>'material-form',
                                    'files' => true,
                                    'data-toggle' => 'validator',
                                ]); ?>

                            <?php endif; ?>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label for="description">Descripcion</label>
                                    <?php echo Form::text('description',old('description'),[
                            			'class'=>'form-control','placeholder'=>'Descripcion',
                            			 'autocomplete'=>'off', 'id' => 'description',
                            			 'data-required-error' => 'Este campo es obligatorio',
                            			 'required' => '', 'maxlength' => '100'
                            		]); ?>

                                    <div class="help-block with-errors"></div>
                                </div>

                                <div class="form-group">
                                    <label for="specification">Especificación</label>
                                    <?php echo Form::text('specification',old('specification'),[
                            			'class'=>'form-control','placeholder'=>'specification',
                            			'required'=>'', 'autocomplete'=>'off', 'id' => 'specification',
                            			'data-required-error' => 'Este campo es obligatorio','maxlength' => '100'
                            		]); ?>

                                    <div class="help-block with-errors"></div>
                                </div>

                                <div class="form-group">
                                    <label for="material_type_id">Tipo de material:</label>
                                    <div class="clearfix"></div>
                                    <?php echo Form::select('material_type_id',[null=>'---Selecionar---']+$material_types->toArray(),old('material_type_id'),[
                                        'class'=>'form-control','id'=>'material_type_id',
                                        'data-required-error' => 'Este campo es obligatorio',
                                    ]); ?>

                                    <div class="help-block with-errors"></div>
                                </div>


                                <div class="form-group">
                                    <label for="thickness">Espesor</label>
                                    <?php echo Form::text('thickness',old('thickness'),[
                            			'class'=>'form-control','placeholder'=>'thickness',
                            			'required'=>'', 'autocomplete'=>'off', 'id' => 'thickness',
                            			'data-required-error' => 'Este campo es obligatorio',
                            			'data-error' => 'Introduce una dirección de correo válida',
                                        'maxlength' => '100'
                            		]); ?>

                                    <div class="help-block with-errors"></div>
                                </div>
                                <div class="form-group">
                                    <label for="dimension">Dimensión</label>
                                    <?php echo Form::text('dimension',old('dimension'),[
                            			'class'=>'form-control','placeholder'=>'dimension',
                            			'required'=>'', 'autocomplete'=>'off', 'id' => 'dimension',
                            			'data-required-error' => 'Este campo es obligatorio', 'maxlength' => '15'
                            		]); ?>

                                    <div class="help-block with-errors"></div>
                                </div>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label for="length">Longitud</label>
                                    <?php echo Form::text('length',old('length'),[
                            			'class'=>'form-control','placeholder'=>'length',
                            			'required'=>'', 'autocomplete'=>'off', 'id' => 'length',
                            			'data-required-error' => 'Este campo es obligatorio', 'maxlength' => '15'
                            		]); ?>

                                    <div class="help-block with-errors"></div>
                                </div>
                                <div class="form-group">
                                    <label for="net_weight">Peso neto</label>
                                    <?php echo Form::text('net_weight',old('net_weight'),[
                            			'class'=>'form-control','placeholder'=>'net_weight',
                            			'required'=>'', 'autocomplete'=>'off', 'id' => 'net_weight',
                            			'data-required-error' => 'Este campo es obligatorio', 'maxlength' => '15'
                            		]); ?>

                                    <div class="help-block with-errors"></div>
                                </div>

                                <div class="form-group">
                                    <label for="gross_weight">Peso bruto</label>
                                    <?php echo Form::text('gross_weight',old('gross_weight'),[
                            			'class'=>'form-control','placeholder'=>'gross_weight',
                            			'required'=>'', 'autocomplete'=>'off', 'id' => 'gross_weight',
                            			'data-required-error' => 'Este campo es obligatorio', 'maxlength' => '15'
                            		]); ?>

                                    <div class="help-block with-errors"></div>
                                </div>

                                <div class="form-group">
                                    <label for="dimension">Marca</label>
                                    <?php echo Form::text('trademark',old('trademark'),[
                            			'class'=>'form-control','placeholder'=>'trademark',
                            			'required'=>'', 'autocomplete'=>'off', 'id' => 'trademark',
                            			'data-required-error' => 'Este campo es obligatorio', 'maxlength' => '15'
                            		]); ?>

                                    <div class="help-block with-errors"></div>
                                </div>

                                <div class="form-group">
                                    <label for="dimension">Precio unitario</label>
                                    <?php echo Form::text('price',old('price'),[
                            			'class'=>'form-control','placeholder'=>'price',
                            			'required'=>'', 'autocomplete'=>'off', 'id' => 'price',
                            			'data-required-error' => 'Este campo es obligatorio', 'maxlength' => '15'
                            		]); ?>

                                    <div class="help-block with-errors"></div>
                                </div>

                                <div>
                                    <button class="btn btn-lg btn-primary pull-right m-t-n-xs" type="submit"><strong>Guardar</strong></button>
                                </div>
                            </div>
                            <?php echo Form::close(); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dyn_js'); ?>


<script type="text/javascript">
    $(function(){

    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\Users\mario\Documents\dev\ricsa\resources\views/ingenieria/materials/createoredit.blade.php */ ?>