<?php $__env->startSection('meta_title'); ?>
    <?php if(!isset($proyect)): ?>
        Crear lista de materiales
    <?php else: ?>
        Editando lista de materiales
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_title'); ?>
    <?php if(!isset($proyect)): ?>
        Crear lista de materiales
    <?php else: ?>
        Editando lista de materiales
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page_action'); ?>
<a href="<?php echo e(route('ingenieria.proyect')); ?>" class="btn btn-white">&lt; Regresar</a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h5>Información</h5>
                    <div class="ibox-tools">
                        <a class="collapse-link">
                            <i class="fa fa-chevron-up"></i>
                        </a>
                    </div>
                </div>
                <div class="ibox-content">
                    <div class="row">
                        <div class="col-sm-4">
                            <h2 class="text-center">Cotizado</h2>
                            <table class="table table-striped table-bordered table-hover dataTables-users" >
                                <thead>
                                <tr>
                                    <th>Materiales</th>
                                    <th>Cant</th>
                                    <th>Medida</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $material_quotation; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quotation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="gradeA" id="item-<?php echo e($quotation->id); ?>">
                                        <td>
                                            <?php echo e($quotation->name); ?>

                                        </td>
                                        <td>
                                            <?php echo e($quotation->quantity); ?>

                                        </td>
                                        <td>
                                            <?php echo e($quotation->material->dimension); ?>

                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="col-sm-8">
                            <div class="row">
                                <h2 class="text-center">RIC_N19_005 / Equipo vertical / Cliente BPM</h2>
                            </div>
                            <table id="mytable" class="table table-striped table-bordered table-hover dataTables-users" >
                                <thead>
                                <tr>
                                    <th>Materiales</th>
                                    <th>Medida</th>
                                    <th>Inventario</th>
                                    <th>Usar</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $inventories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="gradeA" id="item-<?php echo e($inventory->id); ?>">
                                        <td>
                                            <?php echo e($inventory->material->description); ?>

                                        </td>
                                        <td>
                                            <?php echo e($inventory->material->dimension); ?>

                                        </td>
                                        <td>
                                            <?php echo e($inventory->quantity); ?>

                                        </td>
                                        <td>
                                            <input type="checkbox" name="" value="">
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <div class="col-sm-4">
                            <h2> Costo Estimado</h2>
                            <input placeholder="$250,000.00" disabled>
                        </div>
                        <div class="col-sm-8">
                            <h2> Costo Agregado</h2>
                            <input placeholder="$210,000.00" disabled> <br><br>
                            <div class="alert alert-danger fade">
                                <button type="button" class="close" data-dismiss="alert">×</button>
                                Llena todos los campos.
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <button class="btn btn-primary" type="button">Guardar</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dyn_js'); ?>


<script type="text/javascript">
    $(function(){

    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\Users\mario\Documents\dev\ricsa\resources\views/ingenieria/proyects/createoredit.blade.php */ ?>